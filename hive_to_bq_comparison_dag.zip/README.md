# Hive to BigQuery Comparison DAG

This Airflow DAG compares Hive final tables migrated to BigQuery. 
It validates schema, row counts, row-level differences, and column-level mismatches.

## Features
- Schema validation (Hive vs BQ)
- Row count validation
- Row-level difference check
- Column-level difference check
- Summary roll-up report

## Deployment
1. Copy the DAG file to your Airflow DAGs folder.
2. Update `PROJECT_ID`, `AUDIT_DATASET`, `HIVE_TABLES`, and `BQ_TABLES` in the DAG.
3. Ensure `comparison_report` and `comparison_summary` tables exist in BigQuery.
