from airflow import DAG
from airflow.providers.google.cloud.operators.bigquery import BigQueryInsertJobOperator
from airflow.utils.dates import days_ago
from airflow.models.baseoperator import chain

PROJECT_ID = "your-gcp-project"
AUDIT_DATASET = "audit_dataset"
HIVE_TABLES = ["hive_table1", "hive_table2"]
BQ_TABLES = ["bq_table1", "bq_table2"]

default_args = {
    "owner": "airflow",
    "start_date": days_ago(1),
    "retries": 0,
}

with DAG(
    dag_id="hive_to_bq_comparison_dag",
    default_args=default_args,
    schedule_interval=None,
    catchup=False,
    tags=["comparison", "hive", "bigquery"],
) as dag:

    for hive_table, bq_table in zip(HIVE_TABLES, BQ_TABLES):

        schema_validation_insert = BigQueryInsertJobOperator(
            task_id=f"schema_validation_insert_{bq_table}",
            configuration={
                "query": {
                    "query": f'''
                    INSERT INTO `{PROJECT_ID}.{AUDIT_DATASET}.comparison_report`
                    SELECT
                      "{bq_table}" AS table_name,
                      "SCHEMA_MISMATCH" AS check_type,
                      c.column_name,
                      c.data_type AS bq_type,
                      h.data_type AS hive_type,
                      CURRENT_TIMESTAMP() AS run_time
                    FROM `{PROJECT_ID}.{AUDIT_DATASET}.bq_schema` c
                    FULL OUTER JOIN `{PROJECT_ID}.{AUDIT_DATASET}.hive_schema` h
                    ON c.column_name = h.column_name
                    WHERE c.data_type != h.data_type OR c.column_name IS NULL OR h.column_name IS NULL;
                    ''',
                    "useLegacySql": False,
                }
            },
        )

        row_count_check = BigQueryInsertJobOperator(
            task_id=f"row_count_check_{bq_table}",
            configuration={
                "query": {
                    "query": f'''
                    INSERT INTO `{PROJECT_ID}.{AUDIT_DATASET}.comparison_report`
                    SELECT "{bq_table}" AS table_name, "ROW_COUNT" AS check_type,
                           "hive_count" AS column_name, COUNT(*) AS hive_val, NULL AS bq_val, CURRENT_TIMESTAMP()
                    FROM `{PROJECT_ID}.{AUDIT_DATASET}.{hive_table}`
                    UNION ALL
                    SELECT "{bq_table}", "ROW_COUNT", "bq_count", NULL, COUNT(*), CURRENT_TIMESTAMP()
                    FROM `{PROJECT_ID}.{AUDIT_DATASET}.{bq_table}`;
                    ''',
                    "useLegacySql": False,
                }
            },
        )

        row_diff_check = BigQueryInsertJobOperator(
            task_id=f"row_diff_check_{bq_table}",
            configuration={
                "query": {
                    "query": f'''
                    INSERT INTO `{PROJECT_ID}.{AUDIT_DATASET}.comparison_report`
                    SELECT "{bq_table}" AS table_name, "ROW_DIFF" AS check_type,
                           NULL AS column_name, TO_JSON_STRING(hive_row) AS hive_val, TO_JSON_STRING(bq_row) AS bq_val, CURRENT_TIMESTAMP()
                    FROM (
                      SELECT * EXCEPT(hash_key) FROM `{PROJECT_ID}.{AUDIT_DATASET}.{hive_table}`
                    ) hive_row
                    FULL OUTER JOIN (
                      SELECT * EXCEPT(hash_key) FROM `{PROJECT_ID}.{AUDIT_DATASET}.{bq_table}`
                    ) bq_row
                    USING(hash_key)
                    WHERE TO_JSON_STRING(hive_row) != TO_JSON_STRING(bq_row);
                    ''',
                    "useLegacySql": False,
                }
            },
        )

        col_diff_check = BigQueryInsertJobOperator(
            task_id=f"col_diff_check_{bq_table}",
            configuration={
                "query": {
                    "query": f'''
                    INSERT INTO `{PROJECT_ID}.{AUDIT_DATASET}.comparison_report`
                    SELECT "{bq_table}" AS table_name, "COLUMN_DIFF" AS check_type,
                           c.column_name,
                           SAFE_CAST(h.{c.column_name} AS STRING) AS hive_val,
                           SAFE_CAST(b.{c.column_name} AS STRING) AS bq_val,
                           CASE WHEN SAFE_CAST(h.{c.column_name} AS STRING) = SAFE_CAST(b.{c.column_name} AS STRING)
                                THEN "Match" ELSE "Mismatch" END AS status,
                           CURRENT_TIMESTAMP()
                    FROM `{PROJECT_ID}.{AUDIT_DATASET}.{hive_table}` h
                    FULL OUTER JOIN `{PROJECT_ID}.{AUDIT_DATASET}.{bq_table}` b
                    USING(hash_key)
                    CROSS JOIN UNNEST(REGEXP_EXTRACT_ALL(TO_JSON_STRING(h), r'"([^"]+)":')) AS c(column_name);
                    ''',
                    "useLegacySql": False,
                }
            },
        )

        summary_check = BigQueryInsertJobOperator(
            task_id=f"summary_check_{bq_table}",
            configuration={
                "query": {
                    "query": f'''
                    INSERT INTO `{PROJECT_ID}.{AUDIT_DATASET}.comparison_summary`
                    SELECT
                      "{bq_table}" AS table_name,
                      CASE WHEN SUM(CASE WHEN check_type = "SCHEMA_MISMATCH" THEN 1 ELSE 0 END) > 0
                           THEN "Mismatch"
                           ELSE "Match"
                      END AS schema_status,
                      MAX(CASE WHEN check_type = "ROW_COUNT" AND column_name = "hive_count" THEN SAFE_CAST(hive_val AS INT64) END) AS hive_row_count,
                      MAX(CASE WHEN check_type = "ROW_COUNT" AND column_name = "bq_count" THEN SAFE_CAST(bq_val AS INT64) END) AS bq_row_count,
                      COUNTIF(check_type = "ROW_DIFF") AS row_diff_count,
                      COUNTIF(check_type = "COLUMN_DIFF" AND status = "Mismatch") AS col_diff_count,
                      SAFE_DIVIDE(COUNTIF(check_type = "ROW_DIFF"),
                                  NULLIF(MAX(CASE WHEN check_type = "ROW_COUNT" AND column_name = "hive_count" THEN SAFE_CAST(hive_val AS INT64) END),0)) AS row_diff_pct,
                      SAFE_DIVIDE(COUNTIF(check_type = "COLUMN_DIFF" AND status = "Mismatch"),
                                  NULLIF(MAX(CASE WHEN check_type = "ROW_COUNT" AND column_name = "hive_count" THEN SAFE_CAST(hive_val AS INT64) END),0)) AS col_diff_pct,
                      CURRENT_TIMESTAMP() AS run_time
                    FROM `{PROJECT_ID}.{AUDIT_DATASET}.comparison_report`
                    WHERE table_name = "{bq_table}";
                    ''',
                    "useLegacySql": False,
                }
            },
        )

        chain(schema_validation_insert, row_count_check, row_diff_check, col_diff_check, summary_check)
